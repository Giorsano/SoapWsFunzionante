package it.siav.sapone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaponeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaponeApplication.class, args);
	}

}
