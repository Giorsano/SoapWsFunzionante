package it.siav.sapone;

import gs_producing_web_service.Country;
import gs_producing_web_service.Currency;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.util.HashMap;
import java.util.Map;

@Component // indica che è un componente dell'applicazione. E' come @Repository ma piu generico
public class CountryRepository {
    private static final Map<String, Country> countries = new HashMap<>();
    //mappa utilizzata per memorizzare i paesi in quanto non abbiamo un DB su cui lavorare.



    /*
    un metodo annotato con @PostConstruct viene eseguito immediatamente dopo che un bean è stato creato
    ed è stato completamente inizializzato tramite il costruttore o l'iniezione di dipendenze.
    in questo caso, l'annotazione @PostConstruct è utilizzata in initData() per eseguire un metodo all'avvio dell'applicazione
    per inizializzare i dati delle country nel repository.
    La funzione di @PostConstruct è simile a quella di un costruttore in quanto entrambi sono utilizzati
    per inizializzare un oggetto, ma ci sono alcune differenze sostanziali.
    I costruttori vengono chiamati solo alla creazione di un nuovo oggetto,
    mentre i metodi annotati con @PostConstruct possono essere chiamati ogni volta che un bean viene creato o ricreato.
    Inoltre, i metodi annotati con @PostConstruct possono essere sovrascritti dalle sottoclassi.
     */@PostConstruct
    public void initData(){ // metodo usato per creare oggetti, preceduto dall'annotazione @PostConstruct
        Country spain = new Country();  //creiamo un nuovo oggetto di tipo Country
        spain.setCapital("Madrid"); //settiamo un valore agli attributi
        spain.setName("Spain");
        spain.setCurrency(Currency.EUR);
        spain.setPopulation(565151);
        countries.put(spain.getName(), spain); //Inseriamo la creazione nella mappa, mettendo come chiave il nome del paese e
        // come valore l'oggetto contenente tutti gli attributi

        Country poland = new Country();
        poland.setCapital("Warsaw");
        poland.setName("Poland");
        poland.setCurrency(Currency.PLN);
        poland.setPopulation(656151);
        countries.put(poland.getName(), poland);

        Country uk = new Country();
        uk.setCapital("London");
        uk.setName("United Kingdom");
        uk.setCurrency(Currency.GBP);
        uk.setPopulation(152321);
        countries.put(uk.getName(), uk);
    }


        //Il metodo findCountry serve per trovare il paese e accetta un parametro name
        // che rappresenta il nome del paese da cercare
        //e restituisce, in questo caso, l'oggetto Country corrispondente
        // oppure null se non trovato. (vedi Assert.notNull(name, "Il nome della nazione non può essere nullo")).
        public Country findCountry(String name){
        Assert.notNull(name, "Il nome della nazione non può essere nullo");
        return countries.get(name);
    }
}
