package it.siav.sapone;

import gs_producing_web_service.GetCountryRequest;
import gs_producing_web_service.GetCountryResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

/*
  Questa annotazione indica che questa classe è un Endpoint del servizio SOAP.
  un EndPoint è un punto di ingresso di un servizio Web.
  In SOAP è un contatto tra client e server dove il cliente può inviare richieste SOAP al server e quest'ultimo
  può inviare risposte SOAP al client
*/@Endpoint
public class CountryEndpoint {
    /*
    Questa costante serve ad indicare l'URI dello spazio dei nomi del servizio.
    L'URI(Uniform Resource Identifier) è  un identificatore universale per rilevare una risorsa in rete.
    In SOAP è l'indirizzo del servizio web dove il client può fare richieste SOAP al server.
     */private static final String NAMESPACE_URI = "http://spring.io/guides/gs-producing-web-service";

     /*
     Istanziata la classe CountryRepository creata in precedenza per gestire le richieste del client accedendo ai dati
     della classe (in questo caso i paesi).
      */private CountryRepository countryRepository;

      @Autowired
    public CountryEndpoint(CountryRepository countryRepository){
          this.countryRepository = countryRepository;
          /*
          Costruttore dell'oggetto countryRepository con annotazione @Autowired per inniettare le dipendenze della classe
          CountryRepository (ovvero una dipendenza della repository).
          La repository è un pattern di progettazione comunemente utilizzato per gestire l'accesso ai dati. In un applicazione
          solitamente si usa per gestire i dati di un database, filesystem o altre fonti di dati.
          un pattern di progettazione è descrizione di come risolvere un problema di progettazione comune
          in una situazione specifica.
           */
      }

        @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getCountryRequest")
        /*
        PayloadRoot associa un metodo che gestisce il payload del messaggio SOAP ad una richiesta specifica del client.
        Esso quindi gestisce la richiesta del client generando una risposta SOAP dal server.
        Il payload è la parte del messaggio  contenente i dati effettivi che si vogliono trasmettere.
        In SOAP contiene le informazioni specifiche della richiesta o della risposta come un valore di ritorno oppure
        parametri della chiamata di un metodo
         */
        @ResponsePayload // indica che il metodo di gestione del messaggio SOAP restituisce una risposta SOAP al client.
      public GetCountryResponse getCountry(@RequestPayload GetCountryRequest request){
            GetCountryResponse response = new GetCountryResponse();
            response.setCountry(countryRepository.findCountry(request.getName()));
            return response;
            /*
            In sintesi questo metodo prende in input una richiesta con l'annotazione @RequestPayload e viene gestita dal
            @PayloadRoot che genera una risposta SOAP con @ResponsePayload  creando un'oggetto response che,
            con il metodo .setCountry,  utilizza countryRepository per recuperare l'oggetto che serve.
            In ritorno al metodo quindi viene mandata la risposta.
             */
        }

}
