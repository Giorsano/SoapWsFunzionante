package it.siav.sapone;

import jakarta.servlet.ServletRegistration;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.ws.config.annotation.EnableWs;
import org.springframework.ws.config.annotation.WsConfigurerAdapter;
import org.springframework.ws.transport.http.MessageDispatcherServlet;
import org.springframework.ws.wsdl.wsdl11.DefaultWsdl11Definition;
import org.springframework.xml.xsd.SimpleXsdSchema;
import org.springframework.xml.xsd.XsdSchema;

@EnableWs  //annotazione per creare un web service SOAP in spring
@Configuration //Indica che la classe è una classe di configurazione
public class WebServiceConfig extends WsConfigurerAdapter {
    //WsConfigurerAdapter contiene dei metodi per configurare un servizio web service SOAP in spring

    @Bean
    public ServletRegistrationBean<MessageDispatcherServlet> messageDispatcherServlet(ApplicationContext applicationContext){
        MessageDispatcherServlet servlet = new MessageDispatcherServlet();
        servlet.setApplicationContext(applicationContext);
        servlet.setTransformWsdlLocations(true);
        return new ServletRegistrationBean<>(servlet, "/ws"); //Il metodo restituisce una ServletRegistrationBean
        // per il servlet con l'URL "/ws/*".


        /*
        La ServletRegistrationBean<MessageDispatcherServlet> è una classe fornita da Spring e
        registra una servlet personalizzata in contesto web.
        In questo caso registra un MessageDispatcherServlet per gestire le richieste SOAP.
        Un Servlet è una classe Java che crea un interfaccia tra applicazione Web e server web. Essa gestisce
        le richieste HTTP e genera risposte HTTP. Il servlet viene eseguita in un container servlet che è
        una parte di un server web e si occupa di eseguire i servlet.
        In questo caso, essendo che istanzia un MessageDispatcheServlet, gestisce delle richieste SOAP.
        Il MessageDispatcheServlet viene fornito da Spring e gestisce le richieste SOAP. In particolare indirizza
        le richieste SOAP all'endpoint opportuno e crea delle risposte SOAP opportune alla richiesta.
        Il servlet in generale serve per gestire le richieste dinamiche
        l'ApplicationContext è un interfaccia di Spring che rappresenta il contesto di applicazione del progetto.
        Il contesto di applicazione è una rappresentazione del contesto in cui un applicazione è in esecuzione.
        In Spring è un interfaccia che consente l'accesso ai Bean della tua applicazione e fornisce molte configurazioni.
        Può essere considerato un contenitore di bean che serve per gestire, configurare e creare delle istanze dei bean
        della applicazione.
        il metodo setTransformWsdlLocations() indica se le posizioni WSDL devono essere  trasformate in URL assoluti
        (setTransformWsdlLocations(true)) oppure no (setTransformWsdlLocations(false)).
        In questo modo, quando un client richiede il WSDL per il servizio,
        il servlet MessageDispatcherServlet restituirà l'URL assoluto del WSDL invece dell'URL relativo.
        l'URL assoluto contiene tutte le informazioni che servono a trovare una risorsa sul web come il protocollo,
        l'indirizzo IP o nome del server, la porta (se applicabile) e il percorso della risorsa.
        Al contrario un URL relativo, indica solo il percorso della risorsa rispetto alla posizione corrente.
        Ad esempio "/about" sarebbe un URL relativo per indicare la pagina about del sito corrente.
         */
    }


    @Bean(name = "countries")
    public DefaultWsdl11Definition defaultWsdl11Definition(XsdSchema xsdSchema){
        DefaultWsdl11Definition defaultWsdl11Definition = new DefaultWsdl11Definition();
        defaultWsdl11Definition.setPortTypeName("CountriesPort");
        defaultWsdl11Definition.setLocationUri("/ws");
        defaultWsdl11Definition.setTargetNamespace("http://spring.io/guides/gs-producing-web-service");
        defaultWsdl11Definition.setSchema(countriesSchema());
        return defaultWsdl11Definition;

        /*
        DefaultWsdl11Definition è una classe Spring che fornisce un'implementazione per creare un WSDL 1.1

        .setPortTypeName() imposta il portType del WSDL. Il portType è una parte del WSDL e
        descrive le operazioni supportate dal servizio Web

        .setLocationUri() imposta l'URI di posizione del servizio Web, esso indica dove il servizio web è disponibile.

        .setTargetNamespace() imposta lo spazio dei nomi del WSDL. Quest'ultimo serve ad identificare in modo univoco le parti del
        WSDL e serve anche a generare gli URI.

        .setSchema() imposta lo schema XSD utilizzato per generare il WSDL. Quest'ultimo descrive la struttura dei messaggi
        di richiesta e di risposta

         */
    }

    @Bean
    public XsdSchema countriesSchema() {
        return new SimpleXsdSchema(new ClassPathResource("countries.xsd"));
        /*
        questo metodo XsdSchema ritorna un oggetto SimpleXsdScherma che fornisce un'implementazione semplice
        per creare uno schema Xsd.
        Esso prende in input un nuovo ClassPathResource ovvero l'xsd dove andare a creare il WSDL. In questo caso "countries.xsd".
        */
    }
}
