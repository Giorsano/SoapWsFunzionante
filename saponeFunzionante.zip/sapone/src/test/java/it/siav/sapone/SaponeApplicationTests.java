package it.siav.sapone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaponeApplicationTests {

	@Test
	void contextLoads() {
	}

}
